%T�nh n?ng l??ng cua tin hieu huu han x(n) = {1, 2, 3, 4, 5}.
x=1:5;
n=1:5;
[nangLuong] = tinhNangLuong(x, n)


