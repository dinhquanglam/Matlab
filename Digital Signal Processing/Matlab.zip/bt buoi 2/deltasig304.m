n0 = 3
n1 = 0
n2 = 4
[x ,n]= delta_sig(n0,n1,n2);
stem(n,x)