function [x_new n_new] = sig_reflect(x,n)
x_new = x;
n_new = -n
end