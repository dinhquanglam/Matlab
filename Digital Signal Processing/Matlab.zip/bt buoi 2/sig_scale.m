function [x_new n_new] = sig_scale(x,n,k)
x_new = x;
n_new = n*k;
end