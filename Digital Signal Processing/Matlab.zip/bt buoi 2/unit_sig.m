function [x] = unit_sig(n,n0)
x = [(n-n0)]>=0;
    end
    