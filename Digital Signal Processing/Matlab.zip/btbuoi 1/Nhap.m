
x=-10:10;
y=exp(x);
plot(y);