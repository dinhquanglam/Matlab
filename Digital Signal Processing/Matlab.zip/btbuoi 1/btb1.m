clc ; close all; clear all;
%bai1
% a = (65-15)/49;
% b = 15:a:65

% bai2
% b = 0:2:38;

%bai3
% a = randn(10);
% b= eye(10);
% c= a.*b;
% d = a-c;

%bai4
% a = randn(10);
% b= eye(10);
% c= a.*b;
% d = a-c;
% e =b-d;

%bai5
% a = randn(3);
% max(X,[],1) 
% min(X,[],1) 
% max(X,[],2) 
% min(X,[],2) 
% max(X,[],'all') 
% min(X,[],'all') 
