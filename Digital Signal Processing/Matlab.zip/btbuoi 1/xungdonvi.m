n=-10:10;
y=[zeros(1,10) 1 zeros(1,10)]
stem(n,y)